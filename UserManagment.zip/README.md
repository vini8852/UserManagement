# My Next.js + TypeScript App

This is a boilerplate project using **Next.js 14+** and **TypeScript**.

## 🚀 Getting Started

```bash
npm install
npm run dev
```

## 🧱 Tech Stack
- Next.js
- React
- TypeScript
- ESLint + Prettier
